INSERT INTO OFFICE VALUES(1,'Cloud Computing Research Center','7174 Aliquam, Ave','22983946');
INSERT INTO OFFICE VALUES(2,'Multimedia Research Center','970-3326 Cras Road','21041918');
INSERT INTO OFFICE VALUES(3,'Network Coding Research Center','143-2971 Eu, Av.','28051035');
INSERT INTO OFFICE VALUES(4,'Telecommunication Simulation Group','P.O. Box 839, 5711 Duis St.','27869901');
INSERT INTO OFFICE VALUES(5,'Advanced Computer Vision Institute','247-7897 Ligula. Avenue','22000062');
INSERT INTO OFFICE VALUES(6,'Big Data Group','P.O. Box 786, 8965 Et Ave','25473333');
INSERT INTO OFFICE VALUES(7,'Database Group','P.O. Box 610, 3867 Lobortis Road','27159250');
INSERT INTO OFFICE VALUES(8,'Compatibility Tools Group','214-807 Nulla Street','28964438');
